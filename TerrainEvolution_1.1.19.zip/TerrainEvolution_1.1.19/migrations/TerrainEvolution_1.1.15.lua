global.te = {
  tiles = { },
  chunks = { },
  grass_trees = { },
  dirt_trees = { },
  desert_trees = { },
  sand_trees = { },
  nuclear_trees = { },
  dead_trees = { },
  random = game.create_random_generator( )
}

InitBiomeTrees( )
