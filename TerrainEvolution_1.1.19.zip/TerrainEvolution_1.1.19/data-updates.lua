data.raw.fire[ "fire-flame-on-tree" ].tree_dying_factor = 1
