data:extend{
  {
    type = "custom-input",
    name = "show_current_date",
    key_sequence = "EQUALS",
    consuming = "none"
  }
}
