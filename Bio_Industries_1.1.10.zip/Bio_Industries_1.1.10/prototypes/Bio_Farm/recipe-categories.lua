data:extend(
{
  {
    type = "recipe-category",
    name = "biofarm-mod-smelting"
  },

  {
    type = "recipe-category",
    name = "biofarm-mod-crushing"
  },

  {
    type = "recipe-category",
    name = "biofarm-mod-bioreactor"
  },

  {
    type = "recipe-category",
    name = "biofarm-mod-farm"
  },

  {
    type = "recipe-category",
    name = "biofarm-mod-greenhouse"
  },

  {
    type = "recipe-category",
    name = "bi-arboretum"
  },
}
)
