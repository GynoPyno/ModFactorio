--~ local BioInd = require('common')('Bio_Industries')

--~ local ICONPATH = BioInd.modRoot .. "/graphics/icons/"

data:extend({
  {
    type = "ammo-category",
    name = "Bio_Turret_Ammo",
    order = "1"
  },
})
