data.raw["unit-spawner"]["spitter-spawner"].loot =
   {
       {
         count_max = 20,
         count_min = 10,
         item = "stone",
         probability = 1
       }
	 }  
data.raw["unit-spawner"]["biter-spawner"].loot =
   {
       {
         count_max = 20,
         count_min = 10,
         item = "stone",
         probability = 1
       }
	 }  
data.raw["turret"]["small-worm-turret"].loot =
   {
       {
         count_max = 20,
         count_min = 10,
         item = "coal",
         probability = 1
       }
	 }  
data.raw["turret"]["medium-worm-turret"].loot =
   {
       {
         count_max = 30,
         count_min = 20,
         item = "coal",
         probability = 1
       }
	 }  
data.raw["turret"]["big-worm-turret"].loot =
   {
       {
         count_max = 60,
         count_min = 30,
         item = "coal",
         probability = 1
       }
	 }  
data.raw["turret"]["behemoth-worm-turret"].loot =
   {
       {
         count_max = 120,
         count_min = 50,
         item = "coal",
         probability = 1
       }
	 }  
data.raw["unit"]["small-biter"].loot =
   {
       {
         count_max = 20,
         count_min = 2,
         item = "iron-ore",
         probability = 1
       }
	 }  
data.raw["unit"]["small-spitter"].loot =
   {
       {
         count_max = 20,
         count_min = 2,
         item = "copper-ore",
         probability = 1
       }
	 }  
data.raw["unit"]["medium-biter"].loot =
   {
       {
         count_max = 30,
         count_min = 3,
         item = "iron-ore",
         probability = 1
       }
	 }
data.raw["unit"]["medium-spitter"].loot =
   {
       {
         count_max = 30,
         count_min = 3,
         item = "copper-ore",
         probability = 1
       }
	 }  
data.raw["unit"]["big-biter"].loot =
   {
       {
         count_max = 50,
         count_min = 2,
         item = "iron-ore",
         probability = 1
       }
	 }  
data.raw["unit"]["big-spitter"].loot =
   {
       {
         count_max = 50,
         count_min = 5,
         item = "copper-ore",
         probability = 1
       }
	 }  
data.raw["unit"]["behemoth-biter"].loot =
   {
       {
         count_max = 200,
         count_min = 10,
         item = "iron-ore",
         probability = 1
       }
	 }  
data.raw["unit"]["behemoth-spitter"].loot =
   {
       {
         count_max = 200,
         count_min = 10,
         item = "copper-ore",
         probability = 1
       }
	 }  