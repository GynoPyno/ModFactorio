data:extend(
{
	{
	type = "bool-setting",
	name = "py-tank-adjust",
	setting_type = "startup",
	default_value = false,
	order = "e",
	},
}
)
