data:extend {
    {
        type = "recipe-category",
        name = "py-incineration"
    },
    {
        type = "recipe-category",
        name = "py-venting"
    },
    {
        type = "recipe-category",
        name = "py-runoff"
    }
}
