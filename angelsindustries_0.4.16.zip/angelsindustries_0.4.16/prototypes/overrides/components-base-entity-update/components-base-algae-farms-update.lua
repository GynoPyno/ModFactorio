if angelsmods.industries.components then
  local OV = angelsmods.functions.OV
  -- CUSTOM FIXES FOR BASE GAME ASSEMBLERS (+ ANGELS)

  OV.add_prereq("bio-processing-green", "tech-red-circuit")

end