-- ordening
--require("prototypes.ordening.angels-industries-override-ordening") -- TEMPORARY, FILE HAS TO GO *POOF*

-- components tab
require("prototypes.ordening.angels-intermediates")
-- power tab
require("prototypes.ordening.angels-power")
-- logistics tab
require("prototypes.ordening.angels-logistics")
require("prototypes.ordening.angels-personal-equipment")
-- vehicle tab
require("prototypes.ordening.angels-vehicles")
require("prototypes.ordening.angels-vehicle-equipment")
-- combat tab
--require("prototypes.ordening.angels-combat")