local OV = angelsmods.functions.OV

require("prototypes.buildings.nuclear-reactor-updates")
require("prototypes.recipes.angels-reactor")
require("prototypes.angels-industries-override")
require("prototypes.angels-industries-ordening")

OV.execute()
