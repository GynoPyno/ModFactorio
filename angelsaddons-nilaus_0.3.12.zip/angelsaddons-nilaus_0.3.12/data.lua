angelsmods = angelsmods or {}
angelsmods.addons = angelsmods.addons or {}
angelsmods.addons.decorations = angelsmods.addons.decorations or {}
angelsmods.addons.decorations.nialus_tint = {r = 57 / 255, g = 23 / 255, b = 121 / 255, a = 1}

require("prototypes.buildings.deco-nilaus")
require("prototypes.buildings.truck")
require("prototypes.recipes.decorations")
require("prototypes.technology.decorations")
