data:extend(
  {
    {
      type = "item",
      name = "random-dropship",
      icon = "__ERPTbaAB__/graphics/icons/random-dropship.png",
      icon_size = 32,
      subgroup = "space-mining",
      order = "n",
      stack_size = 10000
    }
  }
)
