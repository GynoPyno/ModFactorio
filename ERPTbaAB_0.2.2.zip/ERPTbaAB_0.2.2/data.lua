require("prototypes.item.dropships")
require("prototypes.recipes.dropship-unboxing")

-- force enable mining drills in sea block
settings.startup["bobmods-mining-miningdrills"].value = {}
settings.startup["bobmods-mining-miningdrills"].value = true