data:extend(
{
	{
		type = "bool-setting",
		name = "reprocessing-overhaul",
		setting_type = "startup",
		default_value = true,
	},
 }
 )
