if mods["angelspetrochem"] then
  angelsmods.settings.hide_setting("bool-setting", "angels-enable-inline-tank")
end