local rawmulti = angelsmods.marathon.rawmulti

require("prototypes/recipes/refining-dynamic/slag-stone")
require("prototypes/recipes/refining-dynamic/crushed-smelting")
require("prototypes/recipes/refining-dynamic/crushed-processing")
require("prototypes/recipes/refining-dynamic/crushed-processing-powder-mix")
require("prototypes/recipes/refining-dynamic/chunk-processing")
require("prototypes/recipes/refining-dynamic/chunk-processing-dust-mix")
require("prototypes/recipes/refining-dynamic/crystal-processing")
require("prototypes/recipes/refining-dynamic/crystal-processing-mix")
require("prototypes/recipes/refining-dynamic/pure-processing")
require("prototypes/recipes/refining-dynamic/pure-processing-mix")
require("prototypes/recipes/refining-dynamic/geodes")
require("prototypes/recipes/refining-dynamic/gems")
