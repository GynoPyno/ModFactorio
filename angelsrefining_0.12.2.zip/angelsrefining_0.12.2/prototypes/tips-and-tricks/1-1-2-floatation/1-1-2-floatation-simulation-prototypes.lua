data:extend(
  {
    {
      type     = "sprite",
      name     = "tips-and-tricks-angels-floatation-recipe",
      filename = "__angelsrefining__/graphics/tips-and-tricks/1-1-2-floatation-recipe.png",
      width    = 254,
      height   = 443,
      scale    = 0.5,
      flags    = {
        "icon",
        "no-crop"
      }
    },
  }
)