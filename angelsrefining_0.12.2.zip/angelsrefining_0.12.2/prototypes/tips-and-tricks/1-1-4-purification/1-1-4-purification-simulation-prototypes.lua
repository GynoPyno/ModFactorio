data:extend(
  {
    {
      type     = "sprite",
      name     = "tips-and-tricks-angels-purification-recipe",
      filename = "__angelsrefining__/graphics/tips-and-tricks/1-1-4-purification-recipe.png",
      width    = 229,
      height   = 299,
      scale    = 0.5,
      flags    = {
        "icon",
        "no-crop"
      }
    },
  }
)