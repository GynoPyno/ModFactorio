data:extend(
  {
    {
      type     = "sprite",
      name     = "tips-and-tricks-angels-crushing-recipe",
      filename = "__angelsrefining__/graphics/tips-and-tricks/1-1-1-crushing-recipe.png",
      width    = 254,
      height   = 407,
      scale    = 0.5,
      flags    = {
        "icon",
        "no-crop"
      }
    },
  }
)