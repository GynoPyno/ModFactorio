return {
  "",
  {"tips-and-tricks-description.angels-crushing"},
  {"tips-and-tricks-description.angels-crushing-notes"}
}