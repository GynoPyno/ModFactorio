data:extend(
  {
    {
      type     = "sprite",
      name     = "tips-and-tricks-angels-leaching-recipe",
      filename = "__angelsrefining__/graphics/tips-and-tricks/1-1-3-leaching-recipe.png",
      width    = 310,
      height   = 371,
      scale    = 0.5,
      flags    = {
        "icon",
        "no-crop"
      }
    },
  }
)