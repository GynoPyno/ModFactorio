return {
  "",
  {"tips-and-tricks-description.angels-leaching"},
  {"tips-and-tricks-description.angels-leaching-notes"}
}