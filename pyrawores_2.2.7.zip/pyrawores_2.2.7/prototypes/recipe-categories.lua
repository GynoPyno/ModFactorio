data:extend {
    {
        type = "resource-category",
        name = "ore-quartz"
    },
    {
        type = "resource-category",
        name = "salt-rock"
    },
    {
        type = "resource-category",
        name = "phosphate-rock-02"
    },
    {
        type = "resource-category",
        name = "iron-rock"
    },
    {
        type = "resource-category",
        name = "coal-rock"
    },
    {
        type = "resource-category",
        name = "lead-rock"
    },
    {
        type = "resource-category",
        name = "quartz-rock"
    },
    {
        type = "resource-category",
        name = "aluminium-rock"
    },
    {
        type = "resource-category",
        name = "chromium-rock"
    },
    {
        type = "resource-category",
        name = "copper-rock"
    },
    {
        type = "resource-category",
        name = "nexelit-rock"
    },
    {
        type = "resource-category",
        name = "nickel-rock"
    },
    {
        type = "resource-category",
        name = "tin-rock"
    },
    {
        type = "resource-category",
        name = "titanium-rock"
    },
    {
        type = "resource-category",
        name = "uranium-rock"
    },
    {
        type = "resource-category",
        name = "zinc-rock"
    },
    {
        type = "recipe-category",
        name = "scrubber"
    },
    {
        type = "recipe-category",
        name = "flotation"
    },
    {
        type = "recipe-category",
        name = "wet-scrubber"
    },
    {
        type = "recipe-category",
        name = "hydroclassifier"
    },
    {
        type = "recipe-category",
        name = "electrolyzer"
    },
    {
        type = "recipe-category",
        name = "impact-crusher"
    },
    {
        type = "recipe-category",
        name = "casting"
    },
    {
        type = "recipe-category",
        name = "leaching"
    },
    {
        type = "recipe-category",
        name = "bof"
    },
    {
        type = "recipe-category",
        name = "eaf"
    },
    {
        type = "recipe-category",
        name = "sinter"
    },
    {
        type = "recipe-category",
        name = "drp"
    },
    {
        type = "fuel-category",
        name = "mega-drill-head"
    },
    {
        type = "recipe-category",
        name = "handcrafting"
    },
    {
        type = "recipe-category",
        name = "py-rawores-casting"
    },
    {
        type = "recipe-category",
        name = "py-rawores-smelter"
    },
}
