data:extend {
    {
        type = "recipe-category",
        name = "coal-processing"
    },
    {
        type = "recipe-category",
        name = "distilator"
    },
    {
        type = "recipe-category",
        name = "rectisol"
    },
    {
        type = "recipe-category",
        name = "carbonfilter"
    },
    {
        type = "recipe-category",
        name = "gasifier"
    },
    {
        type = "recipe-category",
        name = "tar"
    },
    {
        type = "recipe-category",
        name = "methanol"
    },
    {
        type = "recipe-category",
        name = "hpf"
    },
    {
        type = "recipe-category",
        name = "quenching-tower"
    },
    {
        type = "recipe-category",
        name = "combustion"
    },
    {
        type = "recipe-category",
        name = "cooling"
    },
    {
        type = "recipe-category",
        name = "evaporator"
    },
    {
        type = "recipe-category",
        name = "desulfurization"
    },
    {
        type = "recipe-category",
        name = "olefin"
    },
    {
        type = "recipe-category",
        name = "soil-extraction"
    },
    {
        type = "recipe-category",
        name = "ground-borer"
    },
    {
        type = "recipe-category",
        name = "fts-reactor"
    },
    {
        type = "recipe-category",
        name = "solid-separator"
    },
    {
        type = "recipe-category",
        name = "washer"
    },
    {
        type = "recipe-category",
        name = "classifier"
    },
    {
        type = "recipe-category",
        name = "advanced-foundry"
    },
    {
        type = "recipe-category",
        name = "co2"
    },
    {
        type = "recipe-category",
        name = "fluid-separator"
    },
    {
        type = "recipe-category",
        name = "fawogae"
    },
    {
        type = "recipe-category",
        name = "ralesia"
    },
    {
        type = "recipe-category",
        name = "ulric"
    },
    {
        type = "recipe-category",
        name = "borax"
    },
    {
        type = "recipe-category",
        name = "niobium"
    },
    {
        type = "recipe-category",
        name = "crusher"
    },
    {
        type = "recipe-category",
        name = "ball-mill"
    },
    {
        type = "recipe-category",
        name = "sand-extractor"
    },
    {
        type = "recipe-category",
        name = "mukmoux"
    },
    {
        type = "recipe-category",
        name = "rare-earth"
    },
    {
        type = "recipe-category",
        name = "advanced-crafting"
    },
    {
        type = "recipe-category",
        name = "nursery"
    },
    {
        type = "recipe-category",
        name = "wpu"
    },
    {
        type = "recipe-category",
        name = "glassworks"
    },
    {
        type = "resource-category",
        name = "borax"
    },
    {
        type = "resource-category",
        name = "niobium"
    },
    {
        type = "fuel-category",
        name = "drill"
    },
}
