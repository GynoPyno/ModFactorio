
data.raw.generator['steam-engine'].maximum_temperature = 500

data.raw.generator['steam-turbine'].maximum_temperature = 2000
