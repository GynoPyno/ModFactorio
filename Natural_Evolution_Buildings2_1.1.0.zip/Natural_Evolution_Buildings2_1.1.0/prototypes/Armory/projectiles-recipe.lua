data:extend({

  ---- Hive Buster Ammo
 

  ---- Bio
 {
    type= "recipe",
    name= "NE_Napalm_Rocket",
	category = "crafting-with-fluid",
    enabled = false,
	energy_required = 12,

	ingredients =
		{
			{type="item", name="flamethrower-ammo", amount=1},
			{type="item", name="explosive-rocket", amount=1},
		},
	
	
    result = "NE-Napalm-Rocket",
	result_count = 1,
 },
 
 
 })