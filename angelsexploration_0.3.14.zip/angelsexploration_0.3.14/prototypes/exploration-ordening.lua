-- exploration
require("prototypes.ordening.exploration-troups")
-- combat
require("prototypes.ordening.exploration-physical")
require("prototypes.ordening.exploration-fire")
require("prototypes.ordening.exploration-explosion")
require("prototypes.ordening.exploration-electric")
require("prototypes.ordening.exploration-artillery")
require("prototypes.ordening.exploration-walls")