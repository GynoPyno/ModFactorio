local tnt = angelsmods.functions.TNT
local description = {"tips-and-tricks-description.angels-native-inhabitants"}

return description