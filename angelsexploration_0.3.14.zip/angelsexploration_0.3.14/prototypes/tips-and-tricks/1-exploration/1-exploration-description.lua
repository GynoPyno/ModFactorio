local tnt = angelsmods.functions.TNT
local description = {"tips-and-tricks-description.angelsexploration"}

return description