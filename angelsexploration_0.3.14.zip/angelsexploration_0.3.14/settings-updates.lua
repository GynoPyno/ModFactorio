if mods["bobenemies"] then
  angelsmods.settings.hide_setting("bool-setting", "bobmods-enemies-enableartifacts", true) -- enable artifacts
end
