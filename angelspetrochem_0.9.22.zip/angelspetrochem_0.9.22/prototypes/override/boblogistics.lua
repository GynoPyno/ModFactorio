local OV = angelsmods.functions.OV

if mods["boblogistics"] then
  -- bob tanks
  angelsmods.functions.move_item("angels-storage-tank-1", "angels-fluid-tanks", "c[large-tank]-c[gas]")
  angelsmods.functions.move_item("angels-storage-tank-2", "angels-fluid-tanks", "c[large-tank]-b[oil]")
  angelsmods.functions.move_item("angels-storage-tank-3", "angels-fluid-tanks", "c[large-tank]-a[inline]")
end