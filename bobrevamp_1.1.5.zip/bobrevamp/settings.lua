data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-revamp-nuclear",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "bobmods-revamp-old-oil",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "bobmods-revamp-oil",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "bobmods-revamp-hardmode",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "bobmods-revamp-rtg",
    setting_type = "startup",
    default_value = true,
  },
}
)

