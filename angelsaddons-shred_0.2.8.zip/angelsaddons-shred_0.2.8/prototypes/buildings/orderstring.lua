
return {
  ["shred"] = "a",
  ["santa"] = "b",
  ["inter"] = "c",
  ["voske"] = "d",
  ["east"]  = "e",
}
