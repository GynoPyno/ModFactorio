data:extend({
    {
        type = "recipe",
        name = "copper-dropship-unboxing",
        category = "satellite-crafting",
        energy_required = 5,
        enabled = "false",
        ingredients = 
        {
            {"copper-dropship", 1},
          },
        result = "copper-ore",
        result_count = 50,
        subgroup = "space-mining",
    }
})