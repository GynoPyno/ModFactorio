data:extend({
    {
      type = "item",
      name = "satellite-communications",
      icon = "__expanded-rocket-payloads__/graphic/satellite-coms-32.png",
      icon_size = 32,
      subgroup = "satellite-intermediaries",
      order = "n",
      stack_size = 5
    }
})