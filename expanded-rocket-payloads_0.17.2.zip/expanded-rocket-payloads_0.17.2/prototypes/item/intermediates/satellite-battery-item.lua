data:extend({
    {
      type = "item",
      name = "satellite-battery",
      icon = "__base__/graphics/icons/battery-mk2-equipment.png",
      icon_size = 64,
      subgroup = "satellite-intermediaries",
      order = "n",
      stack_size = 5
    }
})