data:extend({
    {
        type = "item",
        name = "shuttle-hull",
        icon = "__expanded-rocket-payloads__/graphic/dreamchaser-hull-32.png",
        icon_size = 32,
        subgroup = "shuttle-processies",
        order = "x",
        stack_size = 1,
    }
})