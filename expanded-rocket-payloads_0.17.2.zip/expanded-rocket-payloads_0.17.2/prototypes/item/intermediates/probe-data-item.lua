data:extend({
    {
        type = "item",
        name = "probe-data",
        icon = "__expanded-rocket-payloads__/graphic/pluto-heart-32.png",
        icon_size = 32,
        subgroup = "satellite-data",
        order = "m",
        stack_size = 5,
    }
})