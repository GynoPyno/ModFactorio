data:extend({
    {
        type = "item",
        name = "mining-shuttle",
        icon = "__expanded-rocket-payloads__/graphic/mining-shuttle-32.png",
        icon_size = 32,
        subgroup = "Space-Shuttles",
        stack_size = 1,
        rocket_launch_product = {"landed-mining-shuttle", 1},
    }
})