data:extend({
  {
    type = "item",
    name = "erp-lab",
    icon = "__base__/graphics/icons/lab.png",
    icon_size = 64,
    subgroup = "buildings",
    order = "g",
    place_result = "erp-lab",
    stack_size = 10,
  }
})