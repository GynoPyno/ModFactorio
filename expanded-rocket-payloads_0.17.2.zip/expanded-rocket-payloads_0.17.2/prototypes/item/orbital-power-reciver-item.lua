data:extend({
  {
    type = "item",
    name = "orbital-power-reciver",
    icon = "__expanded-rocket-payloads__/graphic/ground-reciver-32.png",
    icon_size = 32,
    subgroup = "buildings",
    order = "mS",
    place_result = "orbital-power-reciver",
    stack_size = 10
  },
})