if mods["angelsindustries"] and angelsmods.industries.overhaul then
  data.raw.recipe["advanced-uranium-processing"].subgroup = "angels-power-nuclear-processing"
  data.raw.recipe["advanced-uranium-processing"].order = "a[uranium]-b[adv-processing]"
end