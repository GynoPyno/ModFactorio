if mods["angelsbioprocessing"] then
  data:extend(
{
	{
		type = "item",
		name = "algae-orange",
		icon = "__angelsbioprocessing__/graphics/icons/algae-brown.png",
		icon_size = 32,
		subgroup = "bio-processing-brown",
		order = "a",
		stack_size = 200
	},
	{
		type = "item",
		name = "algae-violet",
		icon = "__angelsbioprocessing__/graphics/icons/algae-brown.png",
		icon_size = 32,
		subgroup = "bio-processing-brown",
		order = "a",
		stack_size = 200
	},
}
)
end