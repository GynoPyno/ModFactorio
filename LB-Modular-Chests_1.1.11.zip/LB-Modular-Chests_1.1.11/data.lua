require("circuit-connector-generated-definitions")
require("prototypes.circuit-connector-definitions")

require("prototypes.entity.entities")

require("prototypes.item.modular-chest")
require("prototypes.recipe.modular-chest-recipe")