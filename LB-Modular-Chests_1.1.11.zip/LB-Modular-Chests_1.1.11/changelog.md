# Modular-Chests

# Changelog
* 1.1.11 -
* Updated to Factorio version 1.1
* 0.18.10 - 
* Modular chests placed by construction robots now correctly merge 
* 0.18.9 -
* Updated to Factorio version 0.18
* 0.17.8 -
* Modular Chests now properly maintain the correct force of the player merging the chests (defaulted to "player" force prior to this)
* (thanks to DraLUSAD for posting about this issue)
* 0.17.7 -
* Updated to work with Factorio version 0.17
* Added a new tier of chest (Modular Steel Chest) - more info in Discussion tab
* Code refactored to be more maintainable and allow for more easily adding new tiers of chests
* 0.16.6 -
* Modular chests now work properly with the mod Factorissimo2 and other mods like it. 
* (thanks to sunnybreath for posting about this issue)
* 0.16.5 -
* Added support for Chest sizes: 34, 41, 48 and 55 (by Gaddhi)
* 0.16.4 -
* Modular Chest inventory size increased up to 32 slots (same as the regular iron chest)
* Modular Chests now contain their inventory when merged to larger chests
* Modular Chests are now fast replaceable with other chests
* 0.16.3 - 
* Fixed naming and description of modular chests
* Added logistics wire connection points to modular chests
* 0.16.2 -
* Added item: Modular Chest
* Added Modular Chest sizes: 6, 13, 20 and 27
