circuit_connector_definitions["modular-chest"] = circuit_connector_definitions.create
(
  universal_connector_template,
  {
    { variation = 18, main_offset = {0,0}, shadow_offset = {0,0}, show_shadow = true },
  }
)