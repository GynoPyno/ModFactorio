require("prototypes.recipes.recipe-updates")
require("prototypes.technology.technology-components-updates")
require("prototypes.technology.technology-tech-updates")
require("prototypes.equipment-updates")