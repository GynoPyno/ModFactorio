if mods["boblogistics"] then
  data.raw["int-setting"]["angels-crawlertrain-tier-amount"].default_value = 3
  data.raw["int-setting"]["angels-petrotrain-tier-amount"].default_value = 3
  data.raw["int-setting"]["angels-smeltingtrain-tier-amount"].default_value = 3
end
