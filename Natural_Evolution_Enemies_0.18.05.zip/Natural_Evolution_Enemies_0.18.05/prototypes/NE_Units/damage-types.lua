data:extend({

 --[[
  {
    type = "damage-type",
    name = "Biological"
  },
    ]]
  {
    type = "damage-type",
    name = "ne_wallbreaker"
  },

  {
    type = "damage-type",
    name = "ne_fire"
  },
    
})
