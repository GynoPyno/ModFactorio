

RECIPE {
    type = "recipe",
    name = "sap-01",
    category = "sap",
    hidden = true,
    enabled = true,
    energy_required = 20,
    ingredients = {
    },
    results = {
        {type = 'item', name = 'saps', amount = 1}
    }
}
