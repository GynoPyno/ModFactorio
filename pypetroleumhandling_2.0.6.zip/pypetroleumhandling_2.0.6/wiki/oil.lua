local oil_data =
    {
        title = 'oil',
        body = 'oil_info'
    }

return(oil_data)
