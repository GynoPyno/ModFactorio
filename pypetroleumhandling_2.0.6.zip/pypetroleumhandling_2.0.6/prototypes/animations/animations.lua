--need to figure out how we are doing the animation

data:extend(
{
    {
        type = 'animation',
        name = 'reverse-rocket',

    }
})