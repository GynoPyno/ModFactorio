angelsmods = angelsmods or {}
angelsmods.addons = angelsmods.addons or {}
angelsmods.addons.cab = angelsmods.addons.cab or {}

require("prototypes.cab-category")

require("prototypes.entities.cab")
require("prototypes.entities.equipment")

require("prototypes.recipes.cab-recipe")
require("prototypes.recipes.equipment-recipe")

require("prototypes.technology.cab-technology")
