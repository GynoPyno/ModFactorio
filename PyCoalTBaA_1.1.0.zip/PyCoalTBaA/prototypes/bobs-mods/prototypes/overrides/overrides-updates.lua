
if mods['bobelectronics'] and mods['pyhightech'] then
    data.raw.recipe['basic-circuit-board'].enabled = false
end
