
if mods['boblogistics'] then
   fun.ingredient_replace('borax-mine','transport-belt','basic-transport-belt')
end
