data:extend(
{
--RESOURCE CATEGORIES

--RECIPE CATEGORIES
  --REFINING
  {
    type = "recipe-category",
    name = "ore-processing",
  },
  {
    type = "recipe-category",
    name = "tba-ore-sorting",
  },
  --[[
--SUBGROUPS
  {
    type = "item-subgroup",
    name = "fluids-refining",
	group = "fluids",
	order = "b",
  },
  {
    type = "item-group",
    name = "resource-refining",
    order = "la",
    inventory_order = "la",
    icon = "__angelsrefining__/graphics/item-group/ore-refining.png",
	icon_size = 64,
  },
  ]]--
  }
  )