data:extend 
{
	{
		type = "recipe-category",
		name = "starter-nursery",
	},
	{
		type = "recipe-category",
		name = "fwf-basic",
	},
		{
		type = "recipe-category",
		name = "pulp-basic",
	},
	{
		type = "recipe-category",
		name = "burner-wpu",
	}
}