data:extend(
    {
        {
            type = "item-subgroup",
            name = "py-alienlife-buildings-mk00",
            group = "py-alienlife",
            order = "a-a-a"
        },
        {
            type = "item-subgroup",
            name = "py-alienlife-buildings-mk01",
            group = "py-alienlife",
            order = "a-a-b"
        },
		{
            type = "item-subgroup",
            name = "py-cp-buildings-mk00",
            group = "coal-processing",
            order = "a-a-a"
        },
		        {
            type = "item-subgroup",
            name = "py-cp-buildings-mk01",
            group = "coal-processing",
            order = "a-a-b"
        },
				{
            type = "item-subgroup",
            name = "py-hightech-buildings-mk00",
            group = "py-hightech",
            order = "a-a-a"
        },
		{
            type = "item-subgroup",
            name = "py-hightech-buildings-mk01",
            group = "py-hightech",
            order = "a-a-b"
        },
	}
)
