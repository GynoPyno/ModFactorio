
ITEM {
    type = "tool",
    name = "omni-science-pack",
    icon = "__base__/graphics/icons/production-science-pack.png",
    icon_size = 64,
    subgroup = "py-alienlife-items",
    order = "a-a",
    stack_size = 200,
    durability = 1,
    durability_description_key = "description.science-pack-remaining-amount-key",
    durability_description_value = "description.science-pack-remaining-amount-value"
}