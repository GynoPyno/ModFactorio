fun.ingredient_replace('omnitractor-1', 'pcb1', 'electronic-circuit')

fun.removescipack("steam-power", "logistic-science-pack")
fun.removescipack("omnitech-omnium-power-1", "logistic-science-pack")