TECHNOLOGY {
    type = "technology",
    name = "rare-earth-tech",
    icon = "__pyhightechgraphics__/graphics/technology/rare-earth-tech.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"basic-electronics"},
    effects = {},
    unit = {
        count = 50,
        ingredients = {
            {"automation-science-pack", 2},
            {"logistic-science-pack", 1}
        },
        time = 65
    }
}
