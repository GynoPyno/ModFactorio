TECHNOLOGY {
    type = "technology",
    name = "basic-electronics",
    icon = "__pyhightechgraphics__/graphics/technology/basic-electronics.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"coal-processing-2"},
    effects = {},
    unit = {
        count = 55,
        ingredients = {
            {"automation-science-pack", 1},
            {"logistic-science-pack", 1}
        },
        time = 45
    }
}
