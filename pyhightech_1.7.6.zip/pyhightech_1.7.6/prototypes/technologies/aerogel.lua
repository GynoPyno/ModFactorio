TECHNOLOGY {
    type = "technology",
    name = "aerogel",
    icon = "__pyhightechgraphics__/graphics/technology/aerogel.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"advanced-electronics"},
    effects = {},
    unit = {
        count = 85,
        ingredients = {
            {"automation-science-pack", 3},
            {"logistic-science-pack", 1},
			{"chemical-science-pack", 2},
        },
        time = 45
    }
}
