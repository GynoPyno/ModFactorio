data:extend {
    {
        type = "resource-category",
        name = "phosphate"
    },
    {
        type = "resource-category",
        name = "rare-earth"
    },
    {
        type = "recipe-category",
        name = "clay"
    },
    {
        type = "recipe-category",
        name = "moon"
    },
    {
        type = "recipe-category",
        name = "auog"
    },
    {
        type = "recipe-category",
        name = "arum"
    },
    {
        type = "recipe-category",
        name = "electronic"
    },
    {
        type = "recipe-category",
        name = "pulp"
    },
    {
        type = "recipe-category",
        name = "chip"
    },
    {
        type = "recipe-category",
        name = "pcb"
    },
    {
        type = "recipe-category",
        name = "fbreactor"
    },
    {
        type = "recipe-category",
        name = "nano"
    },
    {
        type = "recipe-category",
        name = "kicalk"
    },
    {
        type = "recipe-category",
        name = "zipir"
    },
    {
        type = "recipe-category",
        name = "quantum"
    },
    {
        type = "recipe-category",
        name = "pa"
    },
    {
        type = "recipe-category",
        name = "handcrafting"
    },
    {
        type = "recipe-category",
        name = "erase"
    },
    {
        type = "fuel-category",
        name = "nexelit"
    },
}
