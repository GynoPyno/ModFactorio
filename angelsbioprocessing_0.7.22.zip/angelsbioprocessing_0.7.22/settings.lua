data:extend(
{
  {
    type = "double-setting",
    name = "angels-bio-tile-pollution-absorbtion-multiplier",
    setting_type = "startup",
    default_value = 2,
    minimum_value = 0,
    maximum_value = 10,
    order = "a"
  },
}
)
