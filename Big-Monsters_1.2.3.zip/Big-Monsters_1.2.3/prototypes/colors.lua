black = {r=0, g=0, b=0, a=1}
magenta = {r=1, g=0, b=1, a=1}
cyan = {r=0, g=1, b=1, a=1}
white = {r=1, g=1, b=1, a=1}
orange = {r=1, g=0.5, b=0, a=1}
blue = {r=0.5, g=0.8, b=1, a=1}
purple = {r=0.8, g=0.5, b=1, a=1}
yellow = {r=1, g=1, b=0.5, a=1}
red = {r=1, g=0.5, b=0.5, a=1}
green = {r=0.5, g=1, b=0.5, a=1}

darkgrey = {r = 0.25, g = 0.25, b = 0.25},
grey = {r = 0.5, g = 0.5, b = 0.5},
lightgrey = {r = 0.75, g = 0.75, b = 0.75},
darkred = {r = 0.5, g = 0, b = 0},
lightred = {r = 1, g = 0.5, b = 0.5},
darkgreen = {r = 0, g = 0.5, b = 0},
lightgreen = {r = 0.5, g = 1, b = 0.5},
darkblue = {r = 0, g = 0, b = 0.5},
lightblue = {r = 0.5, g = 0.5, b = 1},
pink = {r = 1, g = 0, b = 1},
brown = {r = 0.6, g = 0.4, b = 0.1},