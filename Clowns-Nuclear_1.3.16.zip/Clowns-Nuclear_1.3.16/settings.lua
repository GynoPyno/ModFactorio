data:extend(
{
	{
		type = "bool-setting",
		name = "artillery-shells",
		setting_type = "startup",
		default_value = false,
	},
 }
 )
