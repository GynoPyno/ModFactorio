if mods["IndustrialRevolution"] then
  data.raw["bool-setting"]["artillery-shells"].default_value = true
  data.raw["bool-setting"]["artillery-shells"].forced_value = true
end